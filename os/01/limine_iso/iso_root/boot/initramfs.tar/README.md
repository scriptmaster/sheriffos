This is loaded into init ram fs
